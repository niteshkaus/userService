const UserModel = require('../model/user');

exports.create = async (req, res) => {
    if(!req.body.email && !req.body.firstName && req.body.lastName && req.body.phone){
        res.status(400).send({message: "request body is invalid"});
    }

    const user = new UserModel({
        email: req.body.email,
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        phone: req.body.phone,
    });

    await user.save().then(data => {
        res.send({
            message: "User Created Successfully"
        })
    }).catch(err => {
        res.status(400).send({
            message: err.message || "some error occured while creating user"
        })
    });
}
exports.update = async (req, res) => {
    if(!req.body.email && !req.body.firstName && req.body.lastName && req.body.phone){
        res.status(400).send({message: "request body is invalid"});
    }

    const id = req.params.id;
    await UserModel.findByIdAndUpdate(id, req.body, {useFindAndModify: false}).then(data => {
        if(!data){
            res.status(400).send({
                message: 'user not found'
            })
        } else {
            res.status(200).send({message: 'updated successfully.'})
        }
    })
}

exports.findAll = async (req, res) => {
    try {
        const user = await UserModel.find();
        res.status(200).json(user);
    } catch (error) {
        res.status(400).json({
            message: error.message || "some error occured while listing user"
        })
    }
}

exports.findOne = async (req, res) => {
    try {
        const user = await UserModel.findById(req.params.id);
        res.status(200).json(user);
    } catch (error) {
        res.status(400).json({
            message: error.message || "some error occured while listing user"
        })
    }
}

exports.deleteUser = async(req,res) => {
    await UserModel.findByIdAndRemove(req.params.id).then(data => {
        if(!data){
            res.status(400).send({
                message: 'user not found'
            })
        } else {
            res.status(200).send({message: 'deleted successfully.'})
        }
    })
}