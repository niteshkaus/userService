const express = require('express');
const bodyParser = require('body-parser');
const UserRoute = require('./routes/user');

const app = express();
const port = 5000;


app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

const dbConfig = require('./config/database.config.js');
const mongoose = require('mongoose');

mongoose.Promise = global.Promise;

mongoose.connect(dbConfig.url, {
    useNewUrlParser: true
}).then(() => {
    console.log('db connected');
}).catch(err => {
    console.log('db connection fails', err);
    process.exit();
});

app.get('/', (req, res) => {
    console.log('Hello');
    res.send("Hello, Welcome!");
});
app.use('/user', UserRoute);

app.listen(port, () => {
    console.log('app running');
})