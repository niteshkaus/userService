
import React, { Component } from "react";
import Header from "./Header";
import Movies from "./Movie/Movies";


export default class App extends Component {
  constructor(){
    super();

    this.state = {
      title : "Sample movie cards"
    }
  }

  render(){
    return (
      <div>
        <Header title = {this.state.title} />
        <div className="">
          <Movies />
        </div>
      </div>
    )
  }
}
